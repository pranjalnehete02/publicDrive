package com.publicdrive.public_drive_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PublicDriveBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
