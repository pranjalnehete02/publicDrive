package com.example.demo;

public class FileSummary {
    private Long id;
    private String name;
    private String type;
    private String size;
    private String owner;

    public FileSummary(Long id, String name, String type, String size, String owner) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.size = size;
        this.owner = owner;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }
}

