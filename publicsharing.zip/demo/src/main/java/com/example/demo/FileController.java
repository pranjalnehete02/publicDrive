package com.example.demo;

import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.util.List;

@RestController
@RequestMapping("/api")  // All endpoints under /api path
@CrossOrigin(origins = "*", allowedHeaders = "*")  // Allow requests from all origins
public class FileController {

    private final FileService fileService;

    public FileController(FileService fileService) {
        this.fileService = fileService;
    }

    // Upload file endpoint
    @PostMapping("/upload")
    public ResponseEntity<?> uploadFile(@RequestParam("file") MultipartFile file) {
        try {
            FileMetadata fileMetadata = fileService.uploadFile(file);
            return ResponseEntity.status(HttpStatus.CREATED).body(fileMetadata);
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("File upload failed: " + e.getMessage());
        }
    }

    // Download file endpoint
    @GetMapping("/files/download/{sharingToken}")
    public ResponseEntity<?> downloadFile(@PathVariable String sharingToken) {
        try {
            Path filePath = fileService.downloadFile(sharingToken);
            File file = filePath.toFile();
            FileInputStream fileInputStream = new FileInputStream(file);
            InputStreamResource resource = new InputStreamResource(fileInputStream);
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + file.getName() + "\"")
                    .contentType(org.springframework.http.MediaType.APPLICATION_OCTET_STREAM)
                    .contentLength(file.length())
                    .body(resource);
        } catch (IllegalStateException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("File not found: " + e.getMessage());
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error reading file: " + e.getMessage());
        }
    }

//    // New endpoint to view text file as HTML
//    @GetMapping("/files/view/{sharingToken}")
//    public ResponseEntity<String> viewFileAsHtml(@PathVariable String sharingToken) {
//        try {
//            String htmlContent = fileService.convertFileToHtml(sharingToken);
//            return ResponseEntity.ok()
//                    .header(HttpHeaders.CONTENT_TYPE, "text/html")
//                    .body(htmlContent);  // Return HTML content
//        } catch (IllegalStateException e) {
//            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("<h1>File not found or expired</h1>");
//        }
//    }
    @GetMapping("/files/view/{sharingToken}")
    public ResponseEntity<String> viewFileAsHtml(@PathVariable String sharingToken) {
        try {
            String htmlContent = fileService.convertFileToHtml(sharingToken);
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_TYPE, "text/html")
                    .body(htmlContent);  // Serve the HTML file content
        } catch (IllegalStateException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("<h1>File not found or expired</h1>");
        }
    }

    // Share file via email endpoint
    @PostMapping("/files/share")
    public ResponseEntity<?> shareFile(@RequestParam("sharingToken") String sharingToken, @RequestParam("email") String email) {
        try {
            fileService.shareFile(sharingToken, email);
            return ResponseEntity.ok().body("File shared successfully!");
        } catch (IllegalStateException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Error sharing file: " + e.getMessage());
        }
    }

    // Get all files endpoint
    @GetMapping("/files")
    public ResponseEntity<List<FileSummary>> getAllFiles() {
        List<FileSummary> files = fileService.getAllFiles();
        return ResponseEntity.ok(files);
    }
}
