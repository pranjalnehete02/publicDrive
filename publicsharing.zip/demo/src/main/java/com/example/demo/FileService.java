package com.example.demo;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.SecureRandom;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class FileService {

    @Value("${file.storage.location}")
    private String storageLocation;

    private final FileMetadataRepository repository;
    private final JavaMailSender emailSender;

    public FileService(FileMetadataRepository repository, JavaMailSender emailSender) {
        this.repository = repository;
        this.emailSender = emailSender;
    }

    // Upload file method
    public FileMetadata uploadFile(MultipartFile file) throws IOException {
        String fileName = file.getOriginalFilename();
        Path filePath = Paths.get(storageLocation, fileName);
        file.transferTo(filePath);

        FileMetadata fileMetadata = new FileMetadata();
        fileMetadata.setFileName(fileName);
        fileMetadata.setFilePath(filePath.toString());
        fileMetadata.setFileSize(file.getSize());

        // Generate Base62 token for file sharing
        String token = generateBase62Token();
        fileMetadata.setSharingToken(token);

        // Set expiry timestamp (valid for 24 hours)
        fileMetadata.setExpiryTimestamp(System.currentTimeMillis() + (24 * 60 * 60 * 1000));

        return repository.save(fileMetadata);
    }

    // Generate Base62 token for sharing
    private String generateBase62Token() {
        SecureRandom random = new SecureRandom();
        byte[] bytes = new byte[6]; // 6 bytes = 8-character token (Base62)
        random.nextBytes(bytes);
        return base62Encode(bytes);
    }

    // Base62 encoding for the byte array
    private String base62Encode(byte[] input) {
        final String chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        StringBuilder result = new StringBuilder();
        long value = 0;
        for (byte b : input) {
            value = (value << 8) | (b & 0xFF);
            result.append(chars.charAt((int) (value % 62)));
            value /= 62;
        }
        return result.toString();
    }

//    // Convert file to HTML (specifically for text files)
//    public String convertFileToHtml(String sharingToken) {
//        Optional<FileMetadata> fileMetadataOpt = repository.findBySharingToken(sharingToken);
//        if (fileMetadataOpt.isPresent()) {
//            FileMetadata fileMetadata = fileMetadataOpt.get();
//
//            // Check if the token has expired
//            if (fileMetadata.getExpiryTimestamp() < System.currentTimeMillis()) {
//                throw new IllegalStateException("Token expired");
//            }
//
//            // Get the file content
//            Path filePath = Paths.get(fileMetadata.getFilePath());
//            try {
//                String content = new String(Files.readAllBytes(filePath));  // Read content of the file
//
//                // Convert content to HTML
//                return "<html><body><h2>File Content</h2><pre>" + content + "</pre></body></html>";
//            } catch (IOException e) {
//                throw new IllegalStateException("Error reading file", e);
//            }
//
//        } else {
//            throw new IllegalStateException("File not found");
//        }
//    }

public String convertFileToHtml(String sharingToken) {
    Optional<FileMetadata> fileMetadataOpt = repository.findBySharingToken(sharingToken);
    if (fileMetadataOpt.isPresent()) {
        FileMetadata fileMetadata = fileMetadataOpt.get();

        // Check if token has expired
        if (fileMetadata.getExpiryTimestamp() < System.currentTimeMillis()) {
            throw new IllegalStateException("Token expired");
        }

        // Get the file content
        Path filePath = Paths.get(fileMetadata.getFilePath());
        try {
            String content = new String(Files.readAllBytes(filePath));  // Read file content

            // Convert content to HTML
            return "<html><body><h2>File Content</h2><pre>" + content + "</pre></body></html>";
        } catch (IOException e) {
            throw new IllegalStateException("Error reading file", e);
        }

    } else {
        throw new IllegalStateException("File not found");
    }
}

//    // Share file via email
//    public void shareFile(String sharingToken, String email) {
//        Optional<FileMetadata> fileMetadataOpt = repository.findBySharingToken(sharingToken);
//        if (fileMetadataOpt.isPresent()) {
//            FileMetadata fileMetadata = fileMetadataOpt.get();
//            if (fileMetadata.getExpiryTimestamp() < System.currentTimeMillis()) {
//                throw new IllegalStateException("Token expired");
//            }
//
//            String fileUrl = "http://localhost:8080/api/files/view/" + sharingToken;
//
//            // Send email with the file download URL
//            SimpleMailMessage message = new SimpleMailMessage();
//            message.setFrom("rashirptl@gmail.com");
//            message.setTo(email);
//            message.setSubject("File Sharing Token");
//            message.setText("You can view the file from the following link: " + fileUrl);
//            emailSender.send(message);
//        } else {
//            throw new IllegalStateException("File not found");
//        }
//    }
    
    public void shareFile(String sharingToken, String email) {
        Optional<FileMetadata> fileMetadataOpt = repository.findBySharingToken(sharingToken);
        if (fileMetadataOpt.isPresent()) {
            FileMetadata fileMetadata = fileMetadataOpt.get();
            if (fileMetadata.getExpiryTimestamp() < System.currentTimeMillis()) {
                throw new IllegalStateException("Token expired");
            }

            // Updated URL to directly open HTML view
            String fileUrl = "http://localhost:8081/api/files/view/" + sharingToken;

            // Send email with the file view URL
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom("rashirptl@gmail.com");
            message.setTo(email);
            message.setSubject("File Sharing Token");
            message.setText("Click the link below to view the file:\n\n" + fileUrl);
            emailSender.send(message);
        } else {
            throw new IllegalStateException("File not found");
        }
    }


    // Download file method (same as before)
    public Path downloadFile(String sharingToken) {
        Optional<FileMetadata> fileMetadataOpt = repository.findBySharingToken(sharingToken);
        if (fileMetadataOpt.isPresent()) {
            return Paths.get(fileMetadataOpt.get().getFilePath());
        } else {
            throw new IllegalStateException("File not found");
        }
    }

    // Get all files method (same as before)
    public List<FileSummary> getAllFiles() {
        List<FileMetadata> files = repository.findAll();
        return files.stream().map(file -> new FileSummary(
                file.getId(),
                file.getFileName(),
                getFileExtension(file.getFileName()),
                formatSize(file.getFileSize()),
                "Me"
        )).collect(Collectors.toList());
    }

    // Helper methods (same as before)
    private String getFileExtension(String fileName) {
        if (fileName.contains(".")) {
            return fileName.substring(fileName.lastIndexOf(".") + 1);
        }
        return "unknown";
    }

    private String formatSize(long sizeInBytes) {
        double sizeInMB = sizeInBytes / (1024.0 * 1024.0);
        return String.format("%.2fMB", sizeInMB);
    }
}
